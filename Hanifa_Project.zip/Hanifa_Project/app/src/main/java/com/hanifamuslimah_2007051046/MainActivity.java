package com.hanifamuslimah_2007051046;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText edt_base, edt_height;
    private Button btn_calculate;
    private TextView tv_hasil;

    private static final String STATE_HASIL = "static_hasil";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edt_base = (EditText) findViewById(R.id.edt_base);
        edt_height = (EditText) findViewById(R.id.edt_height);
        btn_calculate = (Button) findViewById(R.id.btn_calculate);
        tv_hasil = (EditText) findViewById(R.id.tv_hasil);

        btn_calculate.setOnClickListener(this);

        if (savedInstanceState != null) {
            String hasil = savedInstanceState.getString(STATE_HASIL);
            tv_hasil.setText(hasil);
        }
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.btn_calculate) {
            String base = edt_base.getText().toString().trim();
            String height = edt_height.getText().toString().trim();

            boolean isEmptyFields = false;
            if (TextUtils.isEmpty(base)) {
                isEmptyFields = true;
                edt_base.setError("Fields alas tidak boleh kosong!");
            }
            if (TextUtils.isEmpty(height)) {
                isEmptyFields = true;
                edt_height.setError("Fields tinggi tidak boleh kosong!");
            }
            if (isEmptyFields) {
                double b = Double.parseDouble(base);
                double h = Double.parseDouble(height);
                double area = 0.5 * b * h;
                tv_hasil.setText(String.valueOf(area));
            }
        }

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putString(STATE_HASIL, tv_hasil.getText().toString());
        super.onSaveInstanceState(outState);
    }
}